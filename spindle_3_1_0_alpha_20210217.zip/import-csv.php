<?php
	define('PREPEND_PATH', '');
	$app_dir = dirname(__FILE__);
	include_once("{$app_dir}/lib.php");

	// accept a record as an assoc array, return transformed row ready to insert to table
	$transformFunctions = [
		'game_agents' => function($data, $options = []) {
			if(isset($data['selection_class'])) $data['selection_class'] = pkGivenLookupText($data['selection_class'], 'game_agents', 'selection_class');
			if(isset($data['agenttype1'])) $data['agenttype1'] = pkGivenLookupText($data['agenttype1'], 'game_agents', 'agenttype1');
			if(isset($data['agenttype2'])) $data['agenttype2'] = pkGivenLookupText($data['agenttype2'], 'game_agents', 'agenttype2');
			if(isset($data['gender'])) $data['gender'] = pkGivenLookupText($data['gender'], 'game_agents', 'gender');
			if(isset($data['birthday'])) $data['birthday'] = guessMySQLDateTime($data['birthday']);
			if(isset($data['deathday'])) $data['deathday'] = guessMySQLDateTime($data['deathday']);
			if(isset($data['data_evaluation'])) $data['data_evaluation'] = pkGivenLookupText($data['data_evaluation'], 'game_agents', 'data_evaluation');
			if(isset($data['authority_organization'])) $data['authority_organization'] = pkGivenLookupText($data['authority_organization'], 'game_agents', 'authority_organization');

			return $data;
		},
		'biblio_author' => function($data, $options = []) {
			if(isset($data['game_agent_id'])) $data['game_agent_id'] = pkGivenLookupText($data['game_agent_id'], 'biblio_author', 'game_agent_id');
			if(isset($data['selection_class'])) $data['selection_class'] = pkGivenLookupText($data['selection_class'], 'biblio_author', 'selection_class');
			if(isset($data['agenttype1'])) $data['agenttype1'] = pkGivenLookupText($data['agenttype1'], 'biblio_author', 'agenttype1');
			if(isset($data['agenttype2'])) $data['agenttype2'] = pkGivenLookupText($data['agenttype2'], 'biblio_author', 'agenttype2');
			if(isset($data['gender'])) $data['gender'] = pkGivenLookupText($data['gender'], 'biblio_author', 'gender');
			if(isset($data['birthday'])) $data['birthday'] = guessMySQLDateTime($data['birthday']);
			if(isset($data['deathday'])) $data['deathday'] = guessMySQLDateTime($data['deathday']);
			if(isset($data['data_evaluation'])) $data['data_evaluation'] = pkGivenLookupText($data['data_evaluation'], 'biblio_author', 'data_evaluation');
			if(isset($data['authority_organization'])) $data['authority_organization'] = pkGivenLookupText($data['authority_organization'], 'biblio_author', 'authority_organization');
			if(isset($data['memberID'])) $data['memberID'] = thisOr($data['game_agent_id'], pkGivenLookupText($data['memberID'], 'biblio_author', 'memberID'));
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['game_agent_id'], pkGivenLookupText($data['agent_name'], 'biblio_author', 'agent_name'));

			return $data;
		},
		'biblio_doc' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'biblio_doc', 'author_id');
			if(isset($data['type'])) $data['type'] = pkGivenLookupText($data['type'], 'biblio_doc', 'type');
			if(isset($data['genre'])) $data['genre'] = pkGivenLookupText($data['genre'], 'biblio_doc', 'genre');
			if(isset($data['created'])) $data['created'] = guessMySQLDateTime($data['created']);
			if(isset($data['published'])) $data['published'] = guessMySQLDateTime($data['published']);
			if(isset($data['language'])) $data['language'] = pkGivenLookupText($data['language'], 'biblio_doc', 'language');
			if(isset($data['rights'])) $data['rights'] = pkGivenLookupText($data['rights'], 'biblio_doc', 'rights');
			if(isset($data['data_evaluation'])) $data['data_evaluation'] = pkGivenLookupText($data['data_evaluation'], 'biblio_doc', 'data_evaluation');
			if(isset($data['authority_organization'])) $data['authority_organization'] = pkGivenLookupText($data['authority_organization'], 'biblio_doc', 'authority_organization');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'biblio_doc', 'author_name'));

			return $data;
		},
		'biblio_transcript' => function($data, $options = []) {
			if(isset($data['author_memberID'])) $data['author_memberID'] = pkGivenLookupText($data['author_memberID'], 'biblio_transcript', 'author_memberID');
			if(isset($data['bibliography_title'])) $data['bibliography_title'] = pkGivenLookupText($data['bibliography_title'], 'biblio_transcript', 'bibliography_title');
			if(isset($data['ip_rights'])) $data['ip_rights'] = pkGivenLookupText($data['ip_rights'], 'biblio_transcript', 'ip_rights');
			if(isset($data['author'])) $data['author'] = thisOr($data['author_memberID'], pkGivenLookupText($data['author'], 'biblio_transcript', 'author'));
			if(isset($data['bibliography_id'])) $data['bibliography_id'] = thisOr($data['bibliography_title'], pkGivenLookupText($data['bibliography_id'], 'biblio_transcript', 'bibliography_id'));

			return $data;
		},
		'biblio_token' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'biblio_token', 'author_id');
			if(isset($data['bibliography'])) $data['bibliography'] = pkGivenLookupText($data['bibliography'], 'biblio_token', 'bibliography');
			if(isset($data['transcript'])) $data['transcript'] = pkGivenLookupText($data['transcript'], 'biblio_token', 'transcript');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'biblio_token', 'author_name'));

			return $data;
		},
		'biblio_code_invivo' => function($data, $options = []) {
			if(isset($data['author'])) $data['author'] = pkGivenLookupText($data['author'], 'biblio_code_invivo', 'author');
			if(isset($data['bibliography'])) $data['bibliography'] = pkGivenLookupText($data['bibliography'], 'biblio_code_invivo', 'bibliography');
			if(isset($data['transcript'])) $data['transcript'] = pkGivenLookupText($data['transcript'], 'biblio_code_invivo', 'transcript');
			if(isset($data['token_sequence'])) $data['token_sequence'] = pkGivenLookupText($data['token_sequence'], 'biblio_code_invivo', 'token_sequence');
			if(isset($data['start_date'])) $data['start_date'] = guessMySQLDateTime($data['start_date']);
			if(isset($data['end_date'])) $data['end_date'] = guessMySQLDateTime($data['end_date']);
			if(isset($data['token'])) $data['token'] = thisOr($data['token_sequence'], pkGivenLookupText($data['token'], 'biblio_code_invivo', 'token'));

			return $data;
		},
		'biblio_code_demo' => function($data, $options = []) {

			return $data;
		},
		'bio_author' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_author', 'author_id');
			if(isset($data['selection_class'])) $data['selection_class'] = pkGivenLookupText($data['selection_class'], 'bio_author', 'selection_class');
			if(isset($data['agenttype1'])) $data['agenttype1'] = pkGivenLookupText($data['agenttype1'], 'bio_author', 'agenttype1');
			if(isset($data['agenttype2'])) $data['agenttype2'] = pkGivenLookupText($data['agenttype2'], 'bio_author', 'agenttype2');
			if(isset($data['gender'])) $data['gender'] = pkGivenLookupText($data['gender'], 'bio_author', 'gender');
			if(isset($data['birthday'])) $data['birthday'] = guessMySQLDateTime($data['birthday']);
			if(isset($data['deathday'])) $data['deathday'] = guessMySQLDateTime($data['deathday']);
			if(isset($data['data_evaluation'])) $data['data_evaluation'] = pkGivenLookupText($data['data_evaluation'], 'bio_author', 'data_evaluation');
			if(isset($data['authority_organization'])) $data['authority_organization'] = pkGivenLookupText($data['authority_organization'], 'bio_author', 'authority_organization');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_author', 'author_name'));

			return $data;
		},
		'bio_story' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_story', 'author_id');
			if(isset($data['type'])) $data['type'] = pkGivenLookupText($data['type'], 'bio_story', 'type');
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'bio_story', 'agent_id');
			if(isset($data['collaboration_status'])) $data['collaboration_status'] = pkGivenLookupText($data['collaboration_status'], 'bio_story', 'collaboration_status');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_story', 'author_name'));
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'bio_story', 'agent_name'));

			return $data;
		},
		'bio_chrs' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_chrs', 'author_id');
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'bio_chrs', 'agent_id');
			if(isset($data['bio_story'])) $data['bio_story'] = pkGivenLookupText($data['bio_story'], 'bio_chrs', 'bio_story');
			if(isset($data['bio_character'])) $data['bio_character'] = pkGivenLookupText($data['bio_character'], 'bio_chrs', 'bio_character');
			if(isset($data['bio_archetype'])) $data['bio_archetype'] = pkGivenLookupText($data['bio_archetype'], 'bio_chrs', 'bio_archetype');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_chrs', 'author_name'));
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'bio_chrs', 'agent_name'));

			return $data;
		},
		'bio_storylines' => function($data, $options = []) {
			if(isset($data['biography'])) $data['biography'] = pkGivenLookupText($data['biography'], 'bio_storylines', 'biography');
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_storylines', 'author_id');
			if(isset($data['bibliography'])) $data['bibliography'] = pkGivenLookupText($data['bibliography'], 'bio_storylines', 'bibliography');
			if(isset($data['transcript'])) $data['transcript'] = pkGivenLookupText($data['transcript'], 'bio_storylines', 'transcript');
			if(isset($data['token'])) $data['token'] = pkGivenLookupText($data['token'], 'bio_storylines', 'token');
			if(isset($data['story_act'])) $data['story_act'] = pkGivenLookupText($data['story_act'], 'bio_storylines', 'story_act');
			if(isset($data['character'])) $data['character'] = pkGivenLookupText($data['character'], 'bio_storylines', 'character');
			if(isset($data['storyweaving_scene_no'])) $data['storyweaving_scene_no'] = pkGivenLookupText($data['storyweaving_scene_no'], 'bio_storylines', 'storyweaving_scene_no');
			if(isset($data['character_scene'])) $data['character_scene'] = pkGivenLookupText($data['character_scene'], 'bio_storylines', 'character_scene');
			if(isset($data['character_event'])) $data['character_event'] = pkGivenLookupText($data['character_event'], 'bio_storylines', 'character_event');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_storylines', 'author_name'));
			if(isset($data['token_sequence'])) $data['token_sequence'] = thisOr($data['token'], pkGivenLookupText($data['token_sequence'], 'bio_storylines', 'token_sequence'));
			if(isset($data['role'])) $data['role'] = thisOr($data['character'], pkGivenLookupText($data['role'], 'bio_storylines', 'role'));
			if(isset($data['storyweaving_scene'])) $data['storyweaving_scene'] = thisOr($data['storyweaving_scene_no'], pkGivenLookupText($data['storyweaving_scene'], 'bio_storylines', 'storyweaving_scene'));
			if(isset($data['storyweaving_sequence'])) $data['storyweaving_sequence'] = thisOr($data['storyweaving_scene_no'], pkGivenLookupText($data['storyweaving_sequence'], 'bio_storylines', 'storyweaving_sequence'));
			if(isset($data['storyweaving_theme'])) $data['storyweaving_theme'] = thisOr($data['storyweaving_scene_no'], pkGivenLookupText($data['storyweaving_theme'], 'bio_storylines', 'storyweaving_theme'));

			return $data;
		},
		'bio_storystatic' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'bio_storystatic', 'story');
			if(isset($data['throughline'])) $data['throughline'] = pkGivenLookupText($data['throughline'], 'bio_storystatic', 'throughline');
			if(isset($data['story_character_mc'])) $data['story_character_mc'] = pkGivenLookupText($data['story_character_mc'], 'bio_storystatic', 'story_character_mc');
			if(isset($data['throughline_domain'])) $data['throughline_domain'] = pkGivenLookupText($data['throughline_domain'], 'bio_storystatic', 'throughline_domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'bio_storystatic', 'concern');
			if(isset($data['issue'])) $data['issue'] = pkGivenLookupText($data['issue'], 'bio_storystatic', 'issue');
			if(isset($data['problem'])) $data['problem'] = pkGivenLookupText($data['problem'], 'bio_storystatic', 'problem');
			if(isset($data['solution'])) $data['solution'] = pkGivenLookupText($data['solution'], 'bio_storystatic', 'solution');
			if(isset($data['symptom'])) $data['symptom'] = pkGivenLookupText($data['symptom'], 'bio_storystatic', 'symptom');
			if(isset($data['response'])) $data['response'] = pkGivenLookupText($data['response'], 'bio_storystatic', 'response');
			if(isset($data['catalyst'])) $data['catalyst'] = pkGivenLookupText($data['catalyst'], 'bio_storystatic', 'catalyst');
			if(isset($data['inhibitor'])) $data['inhibitor'] = pkGivenLookupText($data['inhibitor'], 'bio_storystatic', 'inhibitor');
			if(isset($data['benchmark'])) $data['benchmark'] = pkGivenLookupText($data['benchmark'], 'bio_storystatic', 'benchmark');
			if(isset($data['signpost1'])) $data['signpost1'] = pkGivenLookupText($data['signpost1'], 'bio_storystatic', 'signpost1');
			if(isset($data['signpost2'])) $data['signpost2'] = pkGivenLookupText($data['signpost2'], 'bio_storystatic', 'signpost2');
			if(isset($data['signpost3'])) $data['signpost3'] = pkGivenLookupText($data['signpost3'], 'bio_storystatic', 'signpost3');
			if(isset($data['signpost4'])) $data['signpost4'] = pkGivenLookupText($data['signpost4'], 'bio_storystatic', 'signpost4');

			return $data;
		},
		'bio_storyweaving_scenes' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'bio_storyweaving_scenes', 'story');
			if(isset($data['step'])) $data['step'] = pkGivenLookupText($data['step'], 'bio_storyweaving_scenes', 'step');
			if(isset($data['throughline'])) $data['throughline'] = pkGivenLookupText($data['throughline'], 'bio_storyweaving_scenes', 'throughline');
			if(isset($data['domain'])) $data['domain'] = pkGivenLookupText($data['domain'], 'bio_storyweaving_scenes', 'domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'bio_storyweaving_scenes', 'concern');
			if(isset($data['issue'])) $data['issue'] = pkGivenLookupText($data['issue'], 'bio_storyweaving_scenes', 'issue');
			if(isset($data['theme'])) $data['theme'] = pkGivenLookupText($data['theme'], 'bio_storyweaving_scenes', 'theme');

			return $data;
		},
		'bio_chr_scenes' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_chr_scenes', 'author_id');
			if(isset($data['bibliography'])) $data['bibliography'] = pkGivenLookupText($data['bibliography'], 'bio_chr_scenes', 'bibliography');
			if(isset($data['transcript'])) $data['transcript'] = pkGivenLookupText($data['transcript'], 'bio_chr_scenes', 'transcript');
			if(isset($data['token'])) $data['token'] = pkGivenLookupText($data['token'], 'bio_chr_scenes', 'token');
			if(isset($data['invivo_code'])) $data['invivo_code'] = pkGivenLookupText($data['invivo_code'], 'bio_chr_scenes', 'invivo_code');
			if(isset($data['startdate'])) $data['startdate'] = pkGivenLookupText($data['startdate'], 'bio_chr_scenes', 'startdate');
			if(isset($data['herme_code'])) $data['herme_code'] = pkGivenLookupText($data['herme_code'], 'bio_chr_scenes', 'herme_code');
			if(isset($data['chr_element'])) $data['chr_element'] = pkGivenLookupText($data['chr_element'], 'bio_chr_scenes', 'chr_element');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_chr_scenes', 'author_name'));
			if(isset($data['token_sequence'])) $data['token_sequence'] = thisOr($data['token'], pkGivenLookupText($data['token_sequence'], 'bio_chr_scenes', 'token_sequence'));
			if(isset($data['enddate'])) $data['enddate'] = thisOr($data['invivo_code'], pkGivenLookupText($data['enddate'], 'bio_chr_scenes', 'enddate'));
			if(isset($data['person'])) $data['person'] = thisOr($data['invivo_code'], pkGivenLookupText($data['person'], 'bio_chr_scenes', 'person'));
			if(isset($data['place'])) $data['place'] = thisOr($data['invivo_code'], pkGivenLookupText($data['place'], 'bio_chr_scenes', 'place'));
			if(isset($data['impression'])) $data['impression'] = thisOr($data['herme_code'], pkGivenLookupText($data['impression'], 'bio_chr_scenes', 'impression'));
			if(isset($data['noetictension'])) $data['noetictension'] = thisOr($data['herme_code'], pkGivenLookupText($data['noetictension'], 'bio_chr_scenes', 'noetictension'));
			if(isset($data['pc'])) $data['pc'] = thisOr($data['herme_code'], pkGivenLookupText($data['pc'], 'bio_chr_scenes', 'pc'));

			return $data;
		},
		'bio_drama_chr_dev' => function($data, $options = []) {
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'bio_drama_chr_dev', 'agent_id');
			if(isset($data['bio_story'])) $data['bio_story'] = pkGivenLookupText($data['bio_story'], 'bio_drama_chr_dev', 'bio_story');
			if(isset($data['dp_resolve'])) $data['dp_resolve'] = pkGivenLookupText($data['dp_resolve'], 'bio_drama_chr_dev', 'dp_resolve');
			if(isset($data['mc_resolve'])) $data['mc_resolve'] = pkGivenLookupText($data['mc_resolve'], 'bio_drama_chr_dev', 'mc_resolve');
			if(isset($data['illust_resolve'])) $data['illust_resolve'] = pkGivenLookupText($data['illust_resolve'], 'bio_drama_chr_dev', 'illust_resolve');
			if(isset($data['illust_growth'])) $data['illust_growth'] = pkGivenLookupText($data['illust_growth'], 'bio_drama_chr_dev', 'illust_growth');
			if(isset($data['illust_approach'])) $data['illust_approach'] = pkGivenLookupText($data['illust_approach'], 'bio_drama_chr_dev', 'illust_approach');
			if(isset($data['illust_ps_style'])) $data['illust_ps_style'] = pkGivenLookupText($data['illust_ps_style'], 'bio_drama_chr_dev', 'illust_ps_style');
			if(isset($data['noetictension'])) $data['noetictension'] = pkGivenLookupText($data['noetictension'], 'bio_drama_chr_dev', 'noetictension');
			if(isset($data['illust_nt'])) $data['illust_nt'] = pkGivenLookupText($data['illust_nt'], 'bio_drama_chr_dev', 'illust_nt');
			if(isset($data['impression'])) $data['impression'] = pkGivenLookupText($data['impression'], 'bio_drama_chr_dev', 'impression');
			if(isset($data['illust_im'])) $data['illust_im'] = pkGivenLookupText($data['illust_im'], 'bio_drama_chr_dev', 'illust_im');
			if(isset($data['mcs_problem'])) $data['mcs_problem'] = pkGivenLookupText($data['mcs_problem'], 'bio_drama_chr_dev', 'mcs_problem');
			if(isset($data['illust_mcs_problem'])) $data['illust_mcs_problem'] = pkGivenLookupText($data['illust_mcs_problem'], 'bio_drama_chr_dev', 'illust_mcs_problem');
			if(isset($data['illust_mcs_solution'])) $data['illust_mcs_solution'] = pkGivenLookupText($data['illust_mcs_solution'], 'bio_drama_chr_dev', 'illust_mcs_solution');
			if(isset($data['illust_mcs_symptom'])) $data['illust_mcs_symptom'] = pkGivenLookupText($data['illust_mcs_symptom'], 'bio_drama_chr_dev', 'illust_mcs_symptom');
			if(isset($data['illust_mcs_response'])) $data['illust_mcs_response'] = pkGivenLookupText($data['illust_mcs_response'], 'bio_drama_chr_dev', 'illust_mcs_response');
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'bio_drama_chr_dev', 'agent_name'));
			if(isset($data['mcs_solution'])) $data['mcs_solution'] = thisOr($data['mcs_problem'], pkGivenLookupText($data['mcs_solution'], 'bio_drama_chr_dev', 'mcs_solution'));
			if(isset($data['mcs_symptom'])) $data['mcs_symptom'] = thisOr($data['mcs_problem'], pkGivenLookupText($data['mcs_symptom'], 'bio_drama_chr_dev', 'mcs_symptom'));
			if(isset($data['mcs_response'])) $data['mcs_response'] = thisOr($data['mcs_problem'], pkGivenLookupText($data['mcs_response'], 'bio_drama_chr_dev', 'mcs_response'));

			return $data;
		},
		'bio_encounters' => function($data, $options = []) {
			if(isset($data['authorA'])) $data['authorA'] = pkGivenLookupText($data['authorA'], 'bio_encounters', 'authorA');
			if(isset($data['author_nameA'])) $data['author_nameA'] = pkGivenLookupText($data['author_nameA'], 'bio_encounters', 'author_nameA');
			if(isset($data['bibliographyA'])) $data['bibliographyA'] = pkGivenLookupText($data['bibliographyA'], 'bio_encounters', 'bibliographyA');
			if(isset($data['transcriptA'])) $data['transcriptA'] = pkGivenLookupText($data['transcriptA'], 'bio_encounters', 'transcriptA');
			if(isset($data['tokenA'])) $data['tokenA'] = pkGivenLookupText($data['tokenA'], 'bio_encounters', 'tokenA');
			if(isset($data['sceneA'])) $data['sceneA'] = pkGivenLookupText($data['sceneA'], 'bio_encounters', 'sceneA');
			if(isset($data['authorB'])) $data['authorB'] = pkGivenLookupText($data['authorB'], 'bio_encounters', 'authorB');
			if(isset($data['authornameB'])) $data['authornameB'] = pkGivenLookupText($data['authornameB'], 'bio_encounters', 'authornameB');
			if(isset($data['bibliographyB'])) $data['bibliographyB'] = pkGivenLookupText($data['bibliographyB'], 'bio_encounters', 'bibliographyB');
			if(isset($data['transcriptB'])) $data['transcriptB'] = pkGivenLookupText($data['transcriptB'], 'bio_encounters', 'transcriptB');
			if(isset($data['tokenB'])) $data['tokenB'] = pkGivenLookupText($data['tokenB'], 'bio_encounters', 'tokenB');
			if(isset($data['sceneB'])) $data['sceneB'] = pkGivenLookupText($data['sceneB'], 'bio_encounters', 'sceneB');

			return $data;
		},
		'bio_encounter_scenes' => function($data, $options = []) {

			return $data;
		},
		'bio_code_herme' => function($data, $options = []) {
			if(isset($data['biography'])) $data['biography'] = pkGivenLookupText($data['biography'], 'bio_code_herme', 'biography');
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'bio_code_herme', 'agent_id');
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'bio_code_herme', 'author_id');
			if(isset($data['bibliography'])) $data['bibliography'] = pkGivenLookupText($data['bibliography'], 'bio_code_herme', 'bibliography');
			if(isset($data['transcript'])) $data['transcript'] = pkGivenLookupText($data['transcript'], 'bio_code_herme', 'transcript');
			if(isset($data['token_sequence'])) $data['token_sequence'] = pkGivenLookupText($data['token_sequence'], 'bio_code_herme', 'token_sequence');
			if(isset($data['impression'])) $data['impression'] = pkGivenLookupText($data['impression'], 'bio_code_herme', 'impression');
			if(isset($data['noetictension'])) $data['noetictension'] = pkGivenLookupText($data['noetictension'], 'bio_code_herme', 'noetictension');
			if(isset($data['pc'])) $data['pc'] = pkGivenLookupText($data['pc'], 'bio_code_herme', 'pc');
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'bio_code_herme', 'agent_name'));
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'bio_code_herme', 'author_name'));
			if(isset($data['token'])) $data['token'] = thisOr($data['token_sequence'], pkGivenLookupText($data['token'], 'bio_code_herme', 'token'));

			return $data;
		},
		'bio_storydynamic' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'bio_storydynamic', 'story');
			if(isset($data['story_dev_chr'])) $data['story_dev_chr'] = pkGivenLookupText($data['story_dev_chr'], 'bio_storydynamic', 'story_dev_chr');
			if(isset($data['storystatic_ost'])) $data['storystatic_ost'] = pkGivenLookupText($data['storystatic_ost'], 'bio_storydynamic', 'storystatic_ost');
			if(isset($data['mc_problem'])) $data['mc_problem'] = pkGivenLookupText($data['mc_problem'], 'bio_storydynamic', 'mc_problem');
			if(isset($data['mc_resolve'])) $data['mc_resolve'] = pkGivenLookupText($data['mc_resolve'], 'bio_storydynamic', 'mc_resolve');
			if(isset($data['mc_growth'])) $data['mc_growth'] = pkGivenLookupText($data['mc_growth'], 'bio_storydynamic', 'mc_growth');
			if(isset($data['mc_approach'])) $data['mc_approach'] = pkGivenLookupText($data['mc_approach'], 'bio_storydynamic', 'mc_approach');
			if(isset($data['mc_ps_style'])) $data['mc_ps_style'] = pkGivenLookupText($data['mc_ps_style'], 'bio_storydynamic', 'mc_ps_style');
			if(isset($data['os_goal_domain'])) $data['os_goal_domain'] = pkGivenLookupText($data['os_goal_domain'], 'bio_storydynamic', 'os_goal_domain');
			if(isset($data['os_consequence_domain'])) $data['os_consequence_domain'] = pkGivenLookupText($data['os_consequence_domain'], 'bio_storydynamic', 'os_consequence_domain');
			if(isset($data['os_consequence_concern'])) $data['os_consequence_concern'] = pkGivenLookupText($data['os_consequence_concern'], 'bio_storydynamic', 'os_consequence_concern');
			if(isset($data['os_cost_domain'])) $data['os_cost_domain'] = pkGivenLookupText($data['os_cost_domain'], 'bio_storydynamic', 'os_cost_domain');
			if(isset($data['os_cost_concern'])) $data['os_cost_concern'] = pkGivenLookupText($data['os_cost_concern'], 'bio_storydynamic', 'os_cost_concern');
			if(isset($data['os_dividend_domain'])) $data['os_dividend_domain'] = pkGivenLookupText($data['os_dividend_domain'], 'bio_storydynamic', 'os_dividend_domain');
			if(isset($data['os_dividend_concern'])) $data['os_dividend_concern'] = pkGivenLookupText($data['os_dividend_concern'], 'bio_storydynamic', 'os_dividend_concern');
			if(isset($data['os_requirements_domain'])) $data['os_requirements_domain'] = pkGivenLookupText($data['os_requirements_domain'], 'bio_storydynamic', 'os_requirements_domain');
			if(isset($data['os_requirements_concern'])) $data['os_requirements_concern'] = pkGivenLookupText($data['os_requirements_concern'], 'bio_storydynamic', 'os_requirements_concern');
			if(isset($data['os_prerequesites_domain'])) $data['os_prerequesites_domain'] = pkGivenLookupText($data['os_prerequesites_domain'], 'bio_storydynamic', 'os_prerequesites_domain');
			if(isset($data['os_prerequesites_concern'])) $data['os_prerequesites_concern'] = pkGivenLookupText($data['os_prerequesites_concern'], 'bio_storydynamic', 'os_prerequesites_concern');
			if(isset($data['os_preconditions_domain'])) $data['os_preconditions_domain'] = pkGivenLookupText($data['os_preconditions_domain'], 'bio_storydynamic', 'os_preconditions_domain');
			if(isset($data['os_preconditions_concern'])) $data['os_preconditions_concern'] = pkGivenLookupText($data['os_preconditions_concern'], 'bio_storydynamic', 'os_preconditions_concern');
			if(isset($data['os_forewarnings_domain'])) $data['os_forewarnings_domain'] = pkGivenLookupText($data['os_forewarnings_domain'], 'bio_storydynamic', 'os_forewarnings_domain');
			if(isset($data['os_forewarnings_concern'])) $data['os_forewarnings_concern'] = pkGivenLookupText($data['os_forewarnings_concern'], 'bio_storydynamic', 'os_forewarnings_concern');
			if(isset($data['storystatic_chr_mc'])) $data['storystatic_chr_mc'] = thisOr($data['storystatic_ost'], pkGivenLookupText($data['storystatic_chr_mc'], 'bio_storydynamic', 'storystatic_chr_mc'));
			if(isset($data['os_goal_concern'])) $data['os_goal_concern'] = thisOr($data['storystatic_ost'], pkGivenLookupText($data['os_goal_concern'], 'bio_storydynamic', 'os_goal_concern'));

			return $data;
		},
		'hist_author' => function($data, $options = []) {
			if(isset($data['game_agent_id'])) $data['game_agent_id'] = pkGivenLookupText($data['game_agent_id'], 'hist_author', 'game_agent_id');
			if(isset($data['selection_class'])) $data['selection_class'] = pkGivenLookupText($data['selection_class'], 'hist_author', 'selection_class');
			if(isset($data['agenttype1'])) $data['agenttype1'] = pkGivenLookupText($data['agenttype1'], 'hist_author', 'agenttype1');
			if(isset($data['agenttype2'])) $data['agenttype2'] = pkGivenLookupText($data['agenttype2'], 'hist_author', 'agenttype2');
			if(isset($data['gender'])) $data['gender'] = pkGivenLookupText($data['gender'], 'hist_author', 'gender');
			if(isset($data['birthday'])) $data['birthday'] = guessMySQLDateTime($data['birthday']);
			if(isset($data['deathday'])) $data['deathday'] = guessMySQLDateTime($data['deathday']);
			if(isset($data['data_evaluation'])) $data['data_evaluation'] = pkGivenLookupText($data['data_evaluation'], 'hist_author', 'data_evaluation');
			if(isset($data['authority_organization'])) $data['authority_organization'] = pkGivenLookupText($data['authority_organization'], 'hist_author', 'authority_organization');

			return $data;
		},
		'hist_story' => function($data, $options = []) {
			if(isset($data['hist_author_id'])) $data['hist_author_id'] = pkGivenLookupText($data['hist_author_id'], 'hist_story', 'hist_author_id');
			if(isset($data['community_id'])) $data['community_id'] = pkGivenLookupText($data['community_id'], 'hist_story', 'community_id');
			if(isset($data['collaboration_status'])) $data['collaboration_status'] = pkGivenLookupText($data['collaboration_status'], 'hist_story', 'collaboration_status');
			if(isset($data['hist_author_name'])) $data['hist_author_name'] = thisOr($data['hist_author_id'], pkGivenLookupText($data['hist_author_name'], 'hist_story', 'hist_author_name'));

			return $data;
		},
		'hist_story_chrs' => function($data, $options = []) {
			if(isset($data['proj_lead_id'])) $data['proj_lead_id'] = pkGivenLookupText($data['proj_lead_id'], 'hist_story_chrs', 'proj_lead_id');
			if(isset($data['hist_story'])) $data['hist_story'] = pkGivenLookupText($data['hist_story'], 'hist_story_chrs', 'hist_story');
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'hist_story_chrs', 'agent_id');
			if(isset($data['bio_story'])) $data['bio_story'] = pkGivenLookupText($data['bio_story'], 'hist_story_chrs', 'bio_story');
			if(isset($data['story_character'])) $data['story_character'] = pkGivenLookupText($data['story_character'], 'hist_story_chrs', 'story_character');
			if(isset($data['story_archetype'])) $data['story_archetype'] = pkGivenLookupText($data['story_archetype'], 'hist_story_chrs', 'story_archetype');
			if(isset($data['proj_lead_name'])) $data['proj_lead_name'] = thisOr($data['proj_lead_id'], pkGivenLookupText($data['proj_lead_name'], 'hist_story_chrs', 'proj_lead_name'));
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'hist_story_chrs', 'agent_name'));

			return $data;
		},
		'hist_storylines' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'hist_storylines', 'story');
			if(isset($data['story_act'])) $data['story_act'] = pkGivenLookupText($data['story_act'], 'hist_storylines', 'story_act');
			if(isset($data['character'])) $data['character'] = pkGivenLookupText($data['character'], 'hist_storylines', 'character');
			if(isset($data['storyweaving_scene_no'])) $data['storyweaving_scene_no'] = pkGivenLookupText($data['storyweaving_scene_no'], 'hist_storylines', 'storyweaving_scene_no');
			if(isset($data['storyweaving_scene'])) $data['storyweaving_scene'] = pkGivenLookupText($data['storyweaving_scene'], 'hist_storylines', 'storyweaving_scene');
			if(isset($data['storyweaving_sequence'])) $data['storyweaving_sequence'] = pkGivenLookupText($data['storyweaving_sequence'], 'hist_storylines', 'storyweaving_sequence');
			if(isset($data['storyweaving_theme'])) $data['storyweaving_theme'] = pkGivenLookupText($data['storyweaving_theme'], 'hist_storylines', 'storyweaving_theme');
			if(isset($data['characterevent_scene'])) $data['characterevent_scene'] = pkGivenLookupText($data['characterevent_scene'], 'hist_storylines', 'characterevent_scene');
			if(isset($data['character_event'])) $data['character_event'] = pkGivenLookupText($data['character_event'], 'hist_storylines', 'character_event');
			if(isset($data['role'])) $data['role'] = thisOr($data['character'], pkGivenLookupText($data['role'], 'hist_storylines', 'role'));

			return $data;
		},
		'hist_storystatic' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'hist_storystatic', 'story');
			if(isset($data['throughline'])) $data['throughline'] = pkGivenLookupText($data['throughline'], 'hist_storystatic', 'throughline');
			if(isset($data['story_character_mc'])) $data['story_character_mc'] = pkGivenLookupText($data['story_character_mc'], 'hist_storystatic', 'story_character_mc');
			if(isset($data['throughline_domain'])) $data['throughline_domain'] = pkGivenLookupText($data['throughline_domain'], 'hist_storystatic', 'throughline_domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'hist_storystatic', 'concern');
			if(isset($data['issue'])) $data['issue'] = pkGivenLookupText($data['issue'], 'hist_storystatic', 'issue');
			if(isset($data['problem'])) $data['problem'] = pkGivenLookupText($data['problem'], 'hist_storystatic', 'problem');
			if(isset($data['solution'])) $data['solution'] = pkGivenLookupText($data['solution'], 'hist_storystatic', 'solution');
			if(isset($data['symptom'])) $data['symptom'] = pkGivenLookupText($data['symptom'], 'hist_storystatic', 'symptom');
			if(isset($data['response'])) $data['response'] = pkGivenLookupText($data['response'], 'hist_storystatic', 'response');
			if(isset($data['catalyst'])) $data['catalyst'] = pkGivenLookupText($data['catalyst'], 'hist_storystatic', 'catalyst');
			if(isset($data['inhibitor'])) $data['inhibitor'] = pkGivenLookupText($data['inhibitor'], 'hist_storystatic', 'inhibitor');
			if(isset($data['benchmark'])) $data['benchmark'] = pkGivenLookupText($data['benchmark'], 'hist_storystatic', 'benchmark');
			if(isset($data['signpost1'])) $data['signpost1'] = pkGivenLookupText($data['signpost1'], 'hist_storystatic', 'signpost1');
			if(isset($data['signpost2'])) $data['signpost2'] = pkGivenLookupText($data['signpost2'], 'hist_storystatic', 'signpost2');
			if(isset($data['signpost3'])) $data['signpost3'] = pkGivenLookupText($data['signpost3'], 'hist_storystatic', 'signpost3');
			if(isset($data['signpost4'])) $data['signpost4'] = pkGivenLookupText($data['signpost4'], 'hist_storystatic', 'signpost4');

			return $data;
		},
		'hist_storyweaving_scenes' => function($data, $options = []) {
			if(isset($data['story'])) $data['story'] = pkGivenLookupText($data['story'], 'hist_storyweaving_scenes', 'story');
			if(isset($data['step'])) $data['step'] = pkGivenLookupText($data['step'], 'hist_storyweaving_scenes', 'step');
			if(isset($data['throughline'])) $data['throughline'] = pkGivenLookupText($data['throughline'], 'hist_storyweaving_scenes', 'throughline');
			if(isset($data['domain'])) $data['domain'] = pkGivenLookupText($data['domain'], 'hist_storyweaving_scenes', 'domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'hist_storyweaving_scenes', 'concern');
			if(isset($data['issue'])) $data['issue'] = pkGivenLookupText($data['issue'], 'hist_storyweaving_scenes', 'issue');
			if(isset($data['theme'])) $data['theme'] = pkGivenLookupText($data['theme'], 'hist_storyweaving_scenes', 'theme');

			return $data;
		},
		'hist_chr_scenes' => function($data, $options = []) {
			if(isset($data['author_id'])) $data['author_id'] = pkGivenLookupText($data['author_id'], 'hist_chr_scenes', 'author_id');
			if(isset($data['hist_story'])) $data['hist_story'] = pkGivenLookupText($data['hist_story'], 'hist_chr_scenes', 'hist_story');
			if(isset($data['character'])) $data['character'] = pkGivenLookupText($data['character'], 'hist_chr_scenes', 'character');
			if(isset($data['agent_id'])) $data['agent_id'] = pkGivenLookupText($data['agent_id'], 'hist_chr_scenes', 'agent_id');
			if(isset($data['bio_story'])) $data['bio_story'] = pkGivenLookupText($data['bio_story'], 'hist_chr_scenes', 'bio_story');
			if(isset($data['bio_storyline_no'])) $data['bio_storyline_no'] = pkGivenLookupText($data['bio_storyline_no'], 'hist_chr_scenes', 'bio_storyline_no');
			if(isset($data['chr_element'])) $data['chr_element'] = pkGivenLookupText($data['chr_element'], 'hist_chr_scenes', 'chr_element');
			if(isset($data['author_name'])) $data['author_name'] = thisOr($data['author_id'], pkGivenLookupText($data['author_name'], 'hist_chr_scenes', 'author_name'));
			if(isset($data['agent_name'])) $data['agent_name'] = thisOr($data['agent_id'], pkGivenLookupText($data['agent_name'], 'hist_chr_scenes', 'agent_name'));
			if(isset($data['bio_storyline_text'])) $data['bio_storyline_text'] = thisOr($data['bio_storyline_no'], pkGivenLookupText($data['bio_storyline_text'], 'hist_chr_scenes', 'bio_storyline_text'));

			return $data;
		},
		'hist_encounters' => function($data, $options = []) {
			if(isset($data['bio_chrA'])) $data['bio_chrA'] = pkGivenLookupText($data['bio_chrA'], 'hist_encounters', 'bio_chrA');
			if(isset($data['bio_storyA'])) $data['bio_storyA'] = pkGivenLookupText($data['bio_storyA'], 'hist_encounters', 'bio_storyA');
			if(isset($data['bio_storyline'])) $data['bio_storyline'] = pkGivenLookupText($data['bio_storyline'], 'hist_encounters', 'bio_storyline');
			if(isset($data['bio_storytext'])) $data['bio_storytext'] = pkGivenLookupText($data['bio_storytext'], 'hist_encounters', 'bio_storytext');
			if(isset($data['sceneA'])) $data['sceneA'] = pkGivenLookupText($data['sceneA'], 'hist_encounters', 'sceneA');
			if(isset($data['bio_chrB'])) $data['bio_chrB'] = pkGivenLookupText($data['bio_chrB'], 'hist_encounters', 'bio_chrB');
			if(isset($data['bio_storyB'])) $data['bio_storyB'] = pkGivenLookupText($data['bio_storyB'], 'hist_encounters', 'bio_storyB');
			if(isset($data['bio_storylineB'])) $data['bio_storylineB'] = pkGivenLookupText($data['bio_storylineB'], 'hist_encounters', 'bio_storylineB');
			if(isset($data['bio_storytextB'])) $data['bio_storytextB'] = pkGivenLookupText($data['bio_storytextB'], 'hist_encounters', 'bio_storytextB');

			return $data;
		},
		'hist_encounter_scenes' => function($data, $options = []) {

			return $data;
		},
		'hist_community' => function($data, $options = []) {

			return $data;
		},
		'class_agent_selection' => function($data, $options = []) {

			return $data;
		},
		'class_agent_type1' => function($data, $options = []) {

			return $data;
		},
		'class_agent_type2' => function($data, $options = []) {

			return $data;
		},
		'class_character_element' => function($data, $options = []) {

			return $data;
		},
		'class_gender' => function($data, $options = []) {

			return $data;
		},
		'class_authority_agent' => function($data, $options = []) {

			return $data;
		},
		'class_evaluation' => function($data, $options = []) {

			return $data;
		},
		'class_bibliography_type' => function($data, $options = []) {

			return $data;
		},
		'class_bibliography_genre' => function($data, $options = []) {

			return $data;
		},
		'class_authority_library' => function($data, $options = []) {

			return $data;
		},
		'class_rights' => function($data, $options = []) {

			return $data;
		},
		'class_language' => function($data, $options = []) {

			return $data;
		},
		'class_story_collab_type' => function($data, $options = []) {

			return $data;
		},
		'class_story_acts' => function($data, $options = []) {

			return $data;
		},
		'class_story_path' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_steps' => function($data, $options = []) {
			if(isset($data['act'])) $data['act'] = pkGivenLookupText($data['act'], 'class_dramatica_steps', 'act');

			return $data;
		},
		'class_dramatica_throughline' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_signpost' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_domain' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_concern' => function($data, $options = []) {
			if(isset($data['domain'])) $data['domain'] = pkGivenLookupText($data['domain'], 'class_dramatica_concern', 'domain');

			return $data;
		},
		'class_dramatica_issue' => function($data, $options = []) {
			if(isset($data['domain'])) $data['domain'] = pkGivenLookupText($data['domain'], 'class_dramatica_issue', 'domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'class_dramatica_issue', 'concern');

			return $data;
		},
		'class_dramatica_themes' => function($data, $options = []) {
			if(isset($data['domain'])) $data['domain'] = pkGivenLookupText($data['domain'], 'class_dramatica_themes', 'domain');
			if(isset($data['concern'])) $data['concern'] = pkGivenLookupText($data['concern'], 'class_dramatica_themes', 'concern');
			if(isset($data['issue'])) $data['issue'] = pkGivenLookupText($data['issue'], 'class_dramatica_themes', 'issue');

			return $data;
		},
		'class_dramatica_archetype' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_character' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_storypoints1' => function($data, $options = []) {

			return $data;
		},
		'class_dramatica_storypoints2' => function($data, $options = []) {
			if(isset($data['cat1'])) $data['cat1'] = pkGivenLookupText($data['cat1'], 'class_dramatica_storypoints2', 'cat1');

			return $data;
		},
		'class_dramatica_storypoints3' => function($data, $options = []) {
			if(isset($data['cat1'])) $data['cat1'] = pkGivenLookupText($data['cat1'], 'class_dramatica_storypoints3', 'cat1');
			if(isset($data['cat2'])) $data['cat2'] = pkGivenLookupText($data['cat2'], 'class_dramatica_storypoints3', 'cat2');

			return $data;
		},
		'class_dynamicstorypoints' => function($data, $options = []) {
			if(isset($data['cat1'])) $data['cat1'] = pkGivenLookupText($data['cat1'], 'class_dynamicstorypoints', 'cat1');
			if(isset($data['cat2'])) $data['cat2'] = pkGivenLookupText($data['cat2'], 'class_dynamicstorypoints', 'cat2');
			if(isset($data['cat3'])) $data['cat3'] = pkGivenLookupText($data['cat3'], 'class_dynamicstorypoints', 'cat3');

			return $data;
		},
		'class_im' => function($data, $options = []) {

			return $data;
		},
		'class_pc' => function($data, $options = []) {

			return $data;
		},
		'class_nt' => function($data, $options = []) {

			return $data;
		},
		'dictionary' => function($data, $options = []) {

			return $data;
		},
		'class_dictionary1' => function($data, $options = []) {

			return $data;
		},
		'class_dictionary2' => function($data, $options = []) {
			if(isset($data['class1'])) $data['class1'] = pkGivenLookupText($data['class1'], 'class_dictionary2', 'class1');

			return $data;
		},
		'class_dictionary3' => function($data, $options = []) {
			if(isset($data['class1'])) $data['class1'] = pkGivenLookupText($data['class1'], 'class_dictionary3', 'class1');
			if(isset($data['class2'])) $data['class2'] = pkGivenLookupText($data['class2'], 'class_dictionary3', 'class2');

			return $data;
		},
		'class_dictionary4' => function($data, $options = []) {
			if(isset($data['class1'])) $data['class1'] = pkGivenLookupText($data['class1'], 'class_dictionary4', 'class1');
			if(isset($data['class2'])) $data['class2'] = pkGivenLookupText($data['class2'], 'class_dictionary4', 'class2');
			if(isset($data['class3'])) $data['class3'] = pkGivenLookupText($data['class3'], 'class_dictionary4', 'class3');

			return $data;
		},
		'class_dictionary5' => function($data, $options = []) {
			if(isset($data['class1'])) $data['class1'] = pkGivenLookupText($data['class1'], 'class_dictionary5', 'class1');
			if(isset($data['class2'])) $data['class2'] = pkGivenLookupText($data['class2'], 'class_dictionary5', 'class2');
			if(isset($data['class3'])) $data['class3'] = pkGivenLookupText($data['class3'], 'class_dictionary5', 'class3');
			if(isset($data['class4'])) $data['class4'] = pkGivenLookupText($data['class4'], 'class_dictionary5', 'class4');

			return $data;
		},
	];

	// accept a record as an assoc array, return a boolean indicating whether to import or skip record
	$filterFunctions = [
		'game_agents' => function($data, $options = []) { return true; },
		'biblio_author' => function($data, $options = []) { return true; },
		'biblio_doc' => function($data, $options = []) { return true; },
		'biblio_transcript' => function($data, $options = []) { return true; },
		'biblio_token' => function($data, $options = []) { return true; },
		'biblio_code_invivo' => function($data, $options = []) { return true; },
		'biblio_code_demo' => function($data, $options = []) { return true; },
		'bio_author' => function($data, $options = []) { return true; },
		'bio_story' => function($data, $options = []) { return true; },
		'bio_chrs' => function($data, $options = []) { return true; },
		'bio_storylines' => function($data, $options = []) { return true; },
		'bio_storystatic' => function($data, $options = []) { return true; },
		'bio_storyweaving_scenes' => function($data, $options = []) { return true; },
		'bio_chr_scenes' => function($data, $options = []) { return true; },
		'bio_drama_chr_dev' => function($data, $options = []) { return true; },
		'bio_encounters' => function($data, $options = []) { return true; },
		'bio_encounter_scenes' => function($data, $options = []) { return true; },
		'bio_code_herme' => function($data, $options = []) { return true; },
		'bio_storydynamic' => function($data, $options = []) { return true; },
		'hist_author' => function($data, $options = []) { return true; },
		'hist_story' => function($data, $options = []) { return true; },
		'hist_story_chrs' => function($data, $options = []) { return true; },
		'hist_storylines' => function($data, $options = []) { return true; },
		'hist_storystatic' => function($data, $options = []) { return true; },
		'hist_storyweaving_scenes' => function($data, $options = []) { return true; },
		'hist_chr_scenes' => function($data, $options = []) { return true; },
		'hist_encounters' => function($data, $options = []) { return true; },
		'hist_encounter_scenes' => function($data, $options = []) { return true; },
		'hist_community' => function($data, $options = []) { return true; },
		'class_agent_selection' => function($data, $options = []) { return true; },
		'class_agent_type1' => function($data, $options = []) { return true; },
		'class_agent_type2' => function($data, $options = []) { return true; },
		'class_character_element' => function($data, $options = []) { return true; },
		'class_gender' => function($data, $options = []) { return true; },
		'class_authority_agent' => function($data, $options = []) { return true; },
		'class_evaluation' => function($data, $options = []) { return true; },
		'class_bibliography_type' => function($data, $options = []) { return true; },
		'class_bibliography_genre' => function($data, $options = []) { return true; },
		'class_authority_library' => function($data, $options = []) { return true; },
		'class_rights' => function($data, $options = []) { return true; },
		'class_language' => function($data, $options = []) { return true; },
		'class_story_collab_type' => function($data, $options = []) { return true; },
		'class_story_acts' => function($data, $options = []) { return true; },
		'class_story_path' => function($data, $options = []) { return true; },
		'class_dramatica_steps' => function($data, $options = []) { return true; },
		'class_dramatica_throughline' => function($data, $options = []) { return true; },
		'class_dramatica_signpost' => function($data, $options = []) { return true; },
		'class_dramatica_domain' => function($data, $options = []) { return true; },
		'class_dramatica_concern' => function($data, $options = []) { return true; },
		'class_dramatica_issue' => function($data, $options = []) { return true; },
		'class_dramatica_themes' => function($data, $options = []) { return true; },
		'class_dramatica_archetype' => function($data, $options = []) { return true; },
		'class_dramatica_character' => function($data, $options = []) { return true; },
		'class_dramatica_storypoints1' => function($data, $options = []) { return true; },
		'class_dramatica_storypoints2' => function($data, $options = []) { return true; },
		'class_dramatica_storypoints3' => function($data, $options = []) { return true; },
		'class_dynamicstorypoints' => function($data, $options = []) { return true; },
		'class_im' => function($data, $options = []) { return true; },
		'class_pc' => function($data, $options = []) { return true; },
		'class_nt' => function($data, $options = []) { return true; },
		'dictionary' => function($data, $options = []) { return true; },
		'class_dictionary1' => function($data, $options = []) { return true; },
		'class_dictionary2' => function($data, $options = []) { return true; },
		'class_dictionary3' => function($data, $options = []) { return true; },
		'class_dictionary4' => function($data, $options = []) { return true; },
		'class_dictionary5' => function($data, $options = []) { return true; },
	];

	/*
	Hook file for overwriting/amending $transformFunctions and $filterFunctions:
	hooks/import-csv.php
	If found, it's included below

	The way this works is by either completely overwriting any of the above 2 arrays,
	or, more commonly, overwriting a single function, for example:
		$transformFunctions['tablename'] = function($data, $options = []) {
			// new definition here
			// then you must return transformed data
			return $data;
		};

	Another scenario is transforming a specific field and leaving other fields to the default
	transformation. One possible way of doing this is to store the original transformation function
	in GLOBALS array, calling it inside the custom transformation function, then modifying the
	specific field:
		$GLOBALS['originalTransformationFunction'] = $transformFunctions['tablename'];
		$transformFunctions['tablename'] = function($data, $options = []) {
			$data = call_user_func_array($GLOBALS['originalTransformationFunction'], [$data, $options]);
			$data['fieldname'] = 'transformed value';
			return $data;
		};
	*/

	@include("{$app_dir}/hooks/import-csv.php");

	$ui = new CSVImportUI($transformFunctions, $filterFunctions);
